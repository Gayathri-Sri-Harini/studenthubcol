#!/bin/bash
uvicorn main:app --reload
